export const config = {
    db: {
        host: '35.214.213.135',
        user: 'us6drvhgbtr2i',
        password: 'pmjrgvymqzeg',
        database: 'dbkgjb6upfgbzq'
    },
    listPerPage: 10,
};

