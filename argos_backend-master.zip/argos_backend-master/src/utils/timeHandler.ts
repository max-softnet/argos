
export function getNowTime(){
    return Date.now().toString()
}